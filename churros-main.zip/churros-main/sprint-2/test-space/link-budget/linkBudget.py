from abc import abstractmethod
import math
from enum import Enum
import json

class Simulation:
    def __init__(self, name):
        self.name = name
        self.uplinks = []
        self.downlinks = []
        self.satellites = []
        self.noise_floor = 10
        

class Location:
    def __init__(self):
        self.lat = 0
        self.lon = 0
        self.alt = 0

    def __init__(self, lat = 0, lon = 0, alt = 0):
        self.lat = lat  # degrees
        self.lon = lon  # degrees
        self.alt = alt  # meters

    def get_xyz(self):
        # Convet lat, lon, and alt to x, y, and z
        R = 6378137 # Earth's radius in meters
        f_inv = 298.257224 # Earth's flattening inverse
        f = 1.0 / f_inv # Earth's flattening
        cosLat = math.cos(self.lat * math.pi / 180)
        sinLat = math.sin(self.lat * math.pi / 180)

        cosLon = math.cos(self.lon * math.pi / 180)
        sinLon = math.sin(self.lon * math.pi / 180)

        c = 1 / math.sqrt(cosLat * cosLat + (1 - f) * (1 - f) * sinLat * sinLat)
        s = (1 - f) * (1 - f) * c

        x = (R*c + self.alt) * cosLat * cosLon
        y = (R*c + self.alt) * cosLat * sinLon
        z = (R*s + self.alt) * sinLat

        return x, y, z

    # TODO: Implement a method to check whether two points are within line of sight of each other
    def line_of_sight(self, other):
        return True

    def distance(self, other):
        # Calculate the distance between two points
        x_1, y_1, z_1 = self.get_xyz()
        x_2, y_2, z_2 = other.get_xyz()

        # Calculate the distance between the two points in meters
        dist = math.sqrt((x_2 - x_1) * (x_2 - x_1) + (y_2 - y_1) * (y_2 - y_1) + (z_2 - z_1) * (z_2 - z_1))

        return dist


    def from_json(self, json):
        # Set the variables from a JSON object
        for key, value in json.items():
            setattr(self, key, value)
        
    def __str__(self):
        # Output variables as JSON
        return json.dumps(self.__dict__.update({"id": id(self)}))

class UplinkGroundStation:
    def __init__(self, simulation = None, name = "", freq = 0, gain = 0, location = Location()):
        self.simulation = simulation
        self.name = name
        self.freq = freq
        self.gain = gain
        self.location = location

    def power(self):
        power = self.gain
        return power

    def __str__(self):
        # Output variables as JSON
        return json.dumps(self.__dict__.update({"id": id(self)}))
 
class DownlinkGroundStation:
    def __init__(self, simulation = None, name = "", freq = 0, gain = 0, location = Location()):
        self.simulation = simulation
        self.name = name
        self.freq = freq
        self.gain = gain
        self.location = location

    def power(self, desired_uplink):
        power = 0
        for sat in self.simulation.satellites:
            if (sat.freq == desired_uplink.freq and self.location.line_of_sight(sat.location)):
                # Calculate distance between the transmitter and the receiver
                dist = sat.location.distance(self.location)
                # Calculate the power drop due to distance
                power_drop = (dist * 0.01)
                # Calculate received power
                recv_power = (sat.power(desired_uplink) - power_drop) * math.pow(10, self.gain / 10)
                # Add the received power to the total power
                power += recv_power
        if (power < 0):
            power = 0
        return power

    def __str__(self):
        # Output variables as JSON
        return json.dumps(self.__dict__.update({"id": id(self)}))



class Satellite:
    def __init__(self, simulation = None, name = "", freq = 0, gain = 0, location = Location()):
        self.simulation = simulation
        self.name = name
        self.freq = freq
        self.gain = gain
        self.location = location

    def power(self, desired_uplink):
        power = 0
        for gs in self.simulation.uplinks:
            if (gs.freq == self.freq and gs.location.line_of_sight(self.location)):
                # Calculate distance between the transmitter and the receiver
                dist = gs.location.distance(self.location)
                # Calculate the power drop due to distance
                power_drop = (dist * 0.01)
                # Calculate received power
                recv_power = (gs.power() - power_drop) * math.pow(10, self.gain / 10)
                if (gs == desired_uplink):
                    # If the transmitter is the desired transmitter, then multiply the power by the gain of the antenna
                    power += recv_power
                else:
                    # If the transmitter is not the desired transmitter, then subtract the received power from the total signal power
                    power -= recv_power
        if (power < 0):
            power = 0
        return power

        
    def __str__(self):
        # Output variables as JSON
        return json.dumps(self.__dict__.update({"id": id(self)}))



def main():
    simulation = Simulation("Demo Simulation")
    gsu1 = UplinkGroundStation(simulation, "Blue Uplink Ground Station", 100, 10, Location(0, 0, 0))
    gsu2 = UplinkGroundStation(simulation, "Red Uplink Ground Station", 100, 7, Location(0, 0, 0))
    gsd1 = DownlinkGroundStation(simulation, "Blue Downlink Ground Station", 100, 10, Location(0, 0, 0))
    gsd2 = DownlinkGroundStation(simulation, "Red Downlink Ground Station", 100, 10, Location(0, 0, 0))
    sat1 = Satellite(simulation, "Blue Satellite", 100, 10, Location(0, 0, 0))
    simulation.uplinks.append(gsu1)
    simulation.uplinks.append(gsu2)
    simulation.downlinks.append(gsd1)
    simulation.downlinks.append(gsd2)
    simulation.satellites.append(sat1)
    print(gsu1.power())
    print(gsu2.power())
    print(sat1.power(gsu1))
    print(gsd1.power(gsu1))
    print(gsd1.power(gsu2))

if __name__ == "__main__":
    main()