import { createApp } from 'vue'
import App from './App.vue'

// This is the simplest way to create a Vue app
//  (but only works for single page applications)
createApp(App).mount('#app')
