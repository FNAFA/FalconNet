<!--This is the main HTML content for the page - the view component of the model-view-controller-->
<!--Elements preceded with ':' contain variables - such as :style="data.color"-->
<!--Elements preceeded with '@' contain functions calls - such as @submit="submit"-->
<template>
  <div :style="'background-color:' + data.color + '; height: 100vh; width: 100vw; display: flex; align-items: center; justify-content: center;'">
      <form @submit="submit" name="/color">
          <select name="color">
              <option value="red">red</option>
              <option value="green">green</option>
              <option value="blue">blue</option>
              <option value="white">white</option>
          </select>
          <input type="submit"/>
      </form>
  </div>
</template>

<!--Script section - this contains the model component of the model-view-controller-->
<script>
// The base URL for the API server
const APIServer = "http://localhost:8000/api";


// The interval at which the data on the page will refresh
const APIRefreshInterval = 1000;

// This is a list of all API paths that will be requested
// Data from these sources will all be merged into the data variable
// This path is appended to the APIServer variable when sending the GET requests
const sources = [
  "/color"
]

// The default class
export default {
  // The data variable contains the current state of the application
  data () {
      return {
          data: [],
          timer: ''
      }
  },
  // When the page is loaded, pull current data from the API,
  //   then set a timer to pull data every second
  created () {
      this.fetchData();
      this.timer = setInterval(this.fetchData, APIRefreshInterval);
  },
  methods: {
      // Pull data from the API
      async fetchData () {
          // For each source specified, append the source to the APIServer,
          //   send a GET request to that URL, and merge the data into the data variable
          for (let source of sources) {
            const response = await fetch(APIServer + source, {
              method: 'GET'
            })
            this.data = Object.assign({}, this.data, await response.json());
          }
      },
      // Cancel the timer that pulls data from the API when the page is closed
      cancelAutoUpdate () {
          clearInterval(this.timer);
      },
      // Handle form submissions
      submit(event) {
        // Prevent the default action - which is to redirect to the form action URL
        event.preventDefault();
        // Set the submission path to the form name
        var path = event.target.name;
        // Load the form data into a FormData object
        var formData = new FormData(event.target);
        var object = {};
        formData.forEach(function(value, key){
            object[key] = value;
        });
        // Convert the FormData object to a JSON string
        var json = JSON.stringify(object);
        // Send a POST request to the API server with the form data
        fetch(APIServer + path, {
          method: 'POST',
          body: json
        });
        // Update the data on the page to reflect the new data
        this.fetchData();
      }
  },
  // When the page is closed, cancel the timer that pulls data from the API
  beforeUnmount () {
    this.cancelAutoUpdate();
  },
}
</script>