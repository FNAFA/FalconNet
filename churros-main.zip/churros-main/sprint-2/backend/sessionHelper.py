import secrets

def createToken(app, team):
    token = secrets.token_urlsafe(32)
    app.state.sessions.append({"token": token, "team": team})
    return token

# Checks if a token matches one of the list of teams provided, given the app state
def validateToken(token, app, teams):
    for session in app.state.sessions:
        if session["token"] == token:
            if session["team"] in teams:
                return True
    return False