# FastAPI Backend

Serves a basic proof of concept backend.

## Installation

1. Install [Python](https://www.python.org/downloads/)
2. Install requirements with `pip install -r requirements.txt`


## Usage
Run the server with `uvicorn main:app --reload` or just `sh run.sh`

## API Documentation
Full API documentation is available at `/docs` or `/redoc`