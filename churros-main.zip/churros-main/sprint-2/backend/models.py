from pydantic import BaseModel

class Simulation(BaseModel):
    noiseFloor: int

class Team(BaseModel):
    team: str

class Gsu(BaseModel):
    freq: int
    gain: int

class Gsd(BaseModel):
    freq: int
    gain: int

class Sat(BaseModel):
    freq: int
    gain: int
