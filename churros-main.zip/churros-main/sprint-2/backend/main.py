import logging
import logging.config
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from starlette.responses import FileResponse
import sessionHelper
import linkBudget
import models

# Initialize the FastAPI app
app = FastAPI()
# Create the intial simulation - ground stations and satellites hard coded for demo purposes
# GSU = Ground Station Uplink
# GSD = Ground Station Downlink
# SAT = Satellite
app.state.sessions = []
app.state.simulation = linkBudget.Simulation("Demo Simulation")
app.state.gsu = []
app.state.gsd = []
app.state.sat = []
app.state.gsu.append(linkBudget.UplinkGroundStation(app.state.simulation, "Blue Uplink Ground Station", 100, 10, linkBudget.Location(0, 0, 0)))
app.state.gsu.append(linkBudget.UplinkGroundStation(app.state.simulation, "Red Uplink Ground Station", 100, 5, linkBudget.Location(0, 0, 0)))
app.state.gsd.append(linkBudget.DownlinkGroundStation(app.state.simulation, "Blue Downlink Ground Station", 100, 10, linkBudget.Location(0, 0, 0), app.state.gsu[0]))
app.state.gsd.append(linkBudget.DownlinkGroundStation(app.state.simulation, "Red Downlink Ground Station", 100, 10, linkBudget.Location(0, 0, 0), app.state.gsu[0]))
app.state.sat.append(linkBudget.Satellite(app.state.simulation, "Blue atellite", 100, 10, linkBudget.Location(0, 0, 0)))



# Initialize the logger
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
fh = logging.FileHandler('main.log')
fh.setLevel(logging.DEBUG)
logger.addHandler(fh)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
fh.setFormatter(formatter)

# CORS configuration
#   This is necessary to allow the frontend to make requests to the backend 
origins = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)




# Define the routes

# USER ROUTES

# POST /user - creates a session for the user and returns the session token
@app.post("/api/user")
async def generateToken(team: models.Team):
    logger.info("Generating token for %s team", team.team)
    return {
        "token": sessionHelper.createToken(app, team.team),
        "redirect": "/" + team.team
    }


# SIMULATION ROUTES

# GET /simulation - returns the current simulation parameters
@app.get("/api/simulation/one")
async def getSimulation(token: str):
    if not sessionHelper.validateToken(token, app, ["blue", "red", "white"]):
        logger.error("Invalid token used for GET /simulation/one")
        return {"error": "Invalid team token"}

    return {
        "simulation": {
            "one": {
                "noiseFloor": app.state.simulation.noiseFloor
            }
        }
    }

# POST /simulation - sets the current simulation parameters
@app.post("/api/simulation/one")
async def setSimulation(token: str, simulation: models.Simulation):
    if not sessionHelper.validateToken(token, app, ["white"]):
        logger.error("Invalid token used for POST /simulation/one")
        return {"error": "Invalid team token"}
    logger.info("Set simuilation parameters to %s", simulation)

    app.state.simulation.noiseFloor = simulation.noiseFloor
    return {"success": True}



# GROUND STATION ROUTES


# GET /gsu/1 - returns frequency and gain of gsu 1
@app.get("/api/gsu/one")
async def getGsu1(token: str):
    if not sessionHelper.validateToken(token, app, ["blue", "white"]):
        logger.error("Invalid token used for GET /gsu/one")
        return {"error": "Invalid team token"}

    return {
        "gsu": {
            "one": {
                "freq": app.state.gsu[0].freq,
                "gain": app.state.gsu[0].gain
            }
        }
    }

# GET /gsu/2 - returns frequency and gain of gsu 1
@app.get("/api/gsu/two")
async def getGsu2(token: str):
    if not sessionHelper.validateToken(token, app, ["red", "white"]):
        logger.error("Invalid token used for GET /gsu/two")
        return {"error": "Invalid team token"}

    return {
        "gsu":{
            "two": {
                "freq": app.state.gsu[1].freq,
                "gain": app.state.gsu[1].gain
            }
        }
    }

# POST /gsu/1 - sets frequency and gain of gsu 1
@app.post("/api/gsu/one")
async def setGsu1(token: str, gsu: models.Gsu):
    if not sessionHelper.validateToken(token, app, ["blue", "white"]):
        logger.error("Invalid token used for POST /gsu/one")
        return {"error": "Invalid team token"}

    logger.info("Set gsu 1 parameters to %s", gsu)

    # Set the frequency and gain
    app.state.gsu[0].freq = gsu.freq
    app.state.gsu[0].gain = gsu.gain
    return {"success": 1}


# POST /gsu/2 - sets frequency and gain of gsu 2
@app.post("/api/gsu/two")
async def setGsu2(token: str, gsu: models.Gsu):
    if not sessionHelper.validateToken(token, app, ["red", "white"]):
        logger.error("Invalid token used for POST /gsu/two")
        return {"error": "Invalid team token"}

    logger.info("Set gsu 2 parameters to %s", gsu)

    # Set the frequency and gain
    app.state.gsu[1].freq = gsu.freq
    app.state.gsu[1].gain = gsu.gain
    return {"success": 1}

# GET /gsd/1 - returns frequency, gain, and power of gdu 1
@app.get("/api/gsd/one")
async def getGsd1(token: str):
    if not sessionHelper.validateToken(token, app, ["blue", "white"]):
        logger.error("Invalid token used for GET /gsd/one")
        return {"error": "Invalid team token"}

    return {
        "gsd": {
            "one": {
                "freq": app.state.gsd[0].freq,
                "gain": app.state.gsd[0].gain,
                "power": app.state.gsd[0].power(),
                "status": app.state.gsd[0].status()
            }
        }
    }

# GET /gsd/1/speca - returns the spectrometer data for gsd 1
@app.get("/api/speca/gsd/one")
async def getGsd1Speca(token: str):
    if not sessionHelper.validateToken(token, app, ["blue", "white"]):
        logger.error("Invalid token used for GET /gsd/one/speca")
        return {"error": "Invalid team token"}

    return {
        "speca": {
            "gsd": {
                "one": {
                    "freq": app.state.gsd[0].freq,
                    "power": app.state.gsd[0].power(),
                    "bandwidth": 10,
                    "noiseFloor": app.state.simulation.noiseFloor
                }
            }
        }
    }

# GET /gsd/2 - returns frequency, gain, power, and bandwidth of gdu 2
@app.get("/api/gsd/two")
async def getGsd2(token: str):
    if not sessionHelper.validateToken(token, app, ["red", "white"]):
        logger.error("Invalid token used for GET /gsd/two")
        return {"error": "Invalid team token"}

    return {
        "gsd": {
            "two": {
                "freq": app.state.gsd[1].freq,
                "gain": app.state.gsd[1].gain,
                "power": app.state.gsd[1].power(),
                "status": app.state.gsd[1].status()
            }
        }
    }

# GET /gsd/2/speca - returns the spectrometer data for gsd 1
@app.get("/api/speca/gsd/two")
async def getGsd2Speca(token: str):
    if not sessionHelper.validateToken(token, app, ["red", "white"]):
        logger.error("Invalid token used for GET /gsd/two/speca")
        return {"error": "Invalid team token"}

    return {
        "speca": {
            "gsd": {
                "two": {
                    "freq": app.state.gsd[0].freq,
                    "power": app.state.gsd[0].power(),
                    "bandwidth": 10,
                    "noiseFloor": app.state.simulation.noiseFloor
                }
            }
        }
    }

# POST /gsd/1 - sets frequency, gain, and power of gdu 1
@app.post("/api/gsd/one")
async def setGsd1(token: str, gsd: models.Gsd):
    if not sessionHelper.validateToken(token, app, ["blue", "white"]):
        logger.error("Invalid token used for POST /gsd/one")
        return {"error": "Invalid team token"}

    logger.info("Set gsd 1 parameters to %s", gsd)

    # Set the frequency and gain
    app.state.gsd[0].freq = gsd.freq
    app.state.gsd[0].gain = gsd.gain
    return {"success": 1}

# POST /gsd/2 - sets frequency and gain of gdu 2
@app.post("/api/gsd/two")
async def setGsd2(token: str, gsd: models.Gsd):
    if not sessionHelper.validateToken(token, app, ["red", "white"]):
        logger.error("Invalid token used for POST /gsd/two")
        return {"error": "Invalid team token"}

    logger.info("Set gsd 2 parameters to %s", gsd)

    # Set the frequency and gain
    app.state.gsd[1].freq = gsd.freq
    app.state.gsd[1].gain = gsd.gain
    return {"success": 1}



# linkBudget.Satellite ROUTES

# GET /sat/1 - returns frequency and gain of sat 1
@app.get("/api/sat/one")
async def getSat1(token: str):
    if not sessionHelper.validateToken(token, app, ["blue", "white"]):
        logger.error("Invalid token used for GET /sat/one")
        return {"error": "Invalid team token"}

    return {
        "sat": {
            "one": {
                "freq": app.state.sat[0].freq,
                "gain": app.state.sat[0].gain
            }
        }
    }

# POST /sat/1 - sets frequency and gain of sat 1
@app.post("/api/sat/one")
async def setSat1(token: str, sat: models.Sat):
    if not sessionHelper.validateToken(token, app, ["blue", "white"]):
        logger.error("Invalid token used for POST /sat/one")
        return {"error": "Invalid team token"}

    logger.info("Set sat 1 parameters to %s", sat)

    # Set the frequency and gain
    app.state.sat[0].freq = sat.freq
    app.state.sat[0].gain = sat.gain
    return {"success": 1}


# GET /log - returns the log file
@app.get("/api/log")
async def getLog(token: str):
    if not sessionHelper.validateToken(token, app, ["white"]):
        logger.error("Invalid token used for GET /log")
        return {"error": "Invalid team token"}

    return FileResponse("main.log")