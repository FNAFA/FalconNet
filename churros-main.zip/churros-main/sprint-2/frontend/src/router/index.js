import { createRouter, createWebHistory } from 'vue-router'
// import HomeView from '../views/HomeView.vue'

const routes = [
  {
    path: '/',
    name: 'home',
    component: () => import('../views/HomePage.vue')
  },
  {
    path: '/red',
    name: 'Red Team',
    component: () => import('../views/RedView.vue')
  },
  {
        path: '/blue',
        name: 'Blue Team',
        component: () => import('../views/BlueView.vue')
  },
  {
    path: '/white',
    name: 'White Team',
    component: () => import('../views/WhiteView.vue')
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
