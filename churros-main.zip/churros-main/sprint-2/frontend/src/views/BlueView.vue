<template>
    <div>
        <div class="text-block"><strong>Blue Dashboard</strong></div>
        <BlueControls :data="data" :staticdata="staticdata"></BlueControls>
        <SatStatus :data="data" :staticdata="staticdata"></SatStatus>
        <SpectrometerComponent :data="data" :staticdata="staticdata"></SpectrometerComponent>
    </div>
</template>

<script>
    import BlueControls from '@/components/BlueControls.vue';
    import SatStatus from '@/components/SatStatus.vue';
    import SpectrometerComponent from '@/components/SpectrometerComponent.vue';

    const sources = [
        "/gsd/one",
        "/gsu/one",
        "/speca/gsd/one"
    ];
    export default {

        props: {
            data: Object,
            staticdata: Object
        },
        components: {
            BlueControls,
            SatStatus,
            SpectrometerComponent
        },
        created() {
            this.$root.setSources(sources);
            this.$root.fetchEventsList();
        },
        methods: {
            submit(event) {
                console.log(this.$parent);
                this.$parent.submit(event);
            }
        }
    }
</script>