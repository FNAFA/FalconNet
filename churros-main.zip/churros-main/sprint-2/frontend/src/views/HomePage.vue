<template>
    <div>
        <div class="wf-section">
            <div class="text-block">ChURROS</div>
            <div class="text-block-3"><span class="text-span"><strong>TEAM SELECT<br />‍</strong></span></div>
        </div>
        <div class="w-form">
            <form @submit="login" name="/user" class="form form-2">
                <select name="team" class="select-field w-select">
                    <option value="" selected disabled hidden>TEAM SELECT</option>
                    <option value="red">RED TEAM</option>
                    <option value="blue">BLUE TEAM</option>
                    <option value="white">WHITE TEAM</option>
                </select><input type="submit" value="Submit" data-wait="Please wait..." class="submit-button w-button" />
            </form>
        </div>
    </div>

</template>

<style>
    @import '../style/HomeView.css';
</style>

<script>
export default {

    props: {
        data: Object,
        staticdata: Object
    },
    created() {
        this.$root.setSources([]);
    },
    methods: {
        login(event) {
            this.$root.login(event);
        }
    }
}
</script>