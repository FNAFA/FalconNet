<template>
    <div>
        <div class="text-block"><strong>Red Dashboard</strong></div>
        <RedControls :data="data" :staticdata="staticdata"></RedControls>
        <SatStatus :data="data" :staticdata="staticdata"></SatStatus>
    </div>
</template>

<script>
    import RedControls from '@/components/RedControls.vue';
    import SatStatus from '@/components/SatStatus.vue';

    const sources = [
        "/gsd/two",
        "/gsu/two",
    ];
    

    export default {

        props: {
            data: Object,
            staticdata: Object
        },
        components: {
            RedControls,
            SatStatus
        },
        mounted() {
            this.$root.setSources(sources);
            this.$root.fetchEventsList();
        },
        methods: {
            submit(event) {
                console.log(this.$parent);
                this.$parent.submit(event);
            }
        }
    }
</script>