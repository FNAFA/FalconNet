<template>
    <div>
        <div class="text-block"><strong>White Dashboard</strong></div>
        <SatStatus :data="data" :staticdata="staticdata"></SatStatus>
        <SpectrometerComponent :data="data" :staticdata="staticdata"></SpectrometerComponent>
        <a :href="this.$root.getLogLocation()" target="_blank">Download Log</a>
    </div>
</template>

<script>
    import SatStatus from '@/components/SatStatus.vue';
    import SpectrometerComponent from '@/components/SpectrometerComponent.vue';

    const sources = [
        "/gsd/one",
        "/gsd/two",
        "/gsu/one",
        "/gsu/two",
        "/sat/one",
        "/speca/gsd/one",
    ];

    export default {

        props: {
            data: Object,
            staticdata: Object
        },
        components: {
            SatStatus,
            SpectrometerComponent
        },
        created() {
            this.$root.setSources(sources);
            this.$root.fetchEventsList();
        },
        methods: {
            submit(event) {
                console.log(this.$parent);
                this.$parent.submit(event);
            }
        }
    }
</script>