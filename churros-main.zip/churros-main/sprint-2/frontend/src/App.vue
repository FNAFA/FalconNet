<template>
  <div>
    <!--
    <nav class="topNav">
      <router-link to="/">Home</router-link> |
      <router-link to="/spectrometer">Spectrometer</router-link> |
      <router-link to="/red">Red Team</router-link> |
      <router-link to="/blue">Blue Team</router-link> | 
      <router-link to="/white">White Team</router-link>
    </nav>
    -->
    <router-view :data="data" :staticdata="staticdata"/>
  </div>
  
</template>

<style>
  @import 'style/NavView.css';
</style>

<script>
  import VueCookies from 'vue-cookies'
  import router from './router'
  const APIServer = "http://localhost:8000/api";

  var sources = [];
  
  export default {
    data () {
      return {
        data: [],
        timer: ''
      }
    },
    created () {
      this.data = {
        "gsd": {
          "one": {
            "freq": 0,
            "gain": 0,
          },
          "two": {
            "freq": 0,
            "gain": 0
          }
        },
        "gsu": {
          "one": {
            "freq": 0,
            "gain": 0,
          },
          "two": {
            "freq": 0,
            "gain": 0
          }
        },
        "speca": {
          "gsd": {
            "one": {
              "freq": 0,
              "gain": 0,
              "power": 0,
              "bandwidth": 0,
              "noiseFloor": 0,
            },
            "two": {
              "freq": 0,
              "gain": 0,
              "power": 0,
              "bandwidth": 0,
              "noiseFloor": 0,
            }
          },
        }
      };
      this.staticdata = this.data;
      this.staticset = 0;
      this.fetchEventsList();
      this.timer = setInterval(this.fetchEventsList, 1000);
    },
    name: 'HomeView',
    methods: {
      setSources(newSources) {
        sources = newSources;
      },
      async fetchEventsList () {
        for (let source of sources) {
          const response = await fetch(APIServer + source + "?token=" + VueCookies.get("token"), {
            method: 'GET'
          })
          this.data = Object.assign({}, this.data, await response.json());
          if (this.data.error) {
            console.log(this.data.error);
            router.push('/');
          }
        }
        if (this.staticset == 0) {
          this.staticset = 1;
          this.staticdata = this.data;
          console.log("set static");
        }
      },
      cancelAutoUpdate () {
        clearInterval(this.timer);
      },
      submit(event) {
        event.preventDefault();
        var path = event.target.name;
        var formData = new FormData(event.target);
        var object = {};
        formData.forEach(function(value, key){
          object[key] = value;
        });
        var json = JSON.stringify(object);
        fetch(APIServer + path + "?token=" + VueCookies.get("token"), {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: json
        })
        this.fetchEventsList();
    }, 
    login(event) {
      event.preventDefault();
      var path = "/user";
      var formData = new FormData(event.target);
      var object = {};
      formData.forEach(function (value, key) {
        object[key] = value;
      });
      var json = JSON.stringify(object);
      fetch(APIServer + path, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: json,
      })
        .then(res => {
          return res.json();
        })
        .then(json => {
          if (json.token) {
            VueCookies.set("token", json.token, "3h");
            router.push(json.redirect);
            // window.location.href = String(json.redirect);
            
          }
        });
    },
    getLogLocation() {
      return APIServer + "/log?token=" + VueCookies.get("token");
    },
  },
    beforeUnmount () {
      this.cancelAutoUpdate();
    }
  }
  </script>
