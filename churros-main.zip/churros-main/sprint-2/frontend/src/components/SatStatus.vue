<template>
    
    <section class="wf-section">
        <div class="container">
            <h2 class="centered-heading">Sat Link</h2>
            <div class="sat-grid">
                <div id="w-node-_305e8c6e-bc73-6048-bf9a-152be7e3ff8f-49834d40" class="sat-1"><img
                        src="../../public/img/sat.png" alt="" class="sat-image" sizes="80px">
                    <h3>Sat 1</h3>
                    <div class="w-form">
                        <form>
                            <label class="w-radio">
                                <input type="radio" id="LOCK" name="LOCK" value="LOCK" class="w-form-formradioinput w-radio-input" disabled=""/>
                                <span class="w-form-label" for="LOCK">Lock Status: {{data.gsd.two.status}}</span><br/>
                                <span class="w-form-label">Satellite freqency: 100mHz</span>
                            </label>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>


</template>

<style>
    @import '../style/SatStatus.css';
</style>

<script>
    export default {

        props: {
            data: Object,
            staticdata: Object
        }
    }
</script>
