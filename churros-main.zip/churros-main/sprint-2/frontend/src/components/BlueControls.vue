<template>
    <div class="body">
        <div class="w-form">
            <form @submit="submit" name="/gsu/one">
                <div class="text-block"><strong>Uplink Ground Station (Transmit)</strong></div>
                <div><strong>Frequency</strong></div><input type="number" class="w-input" maxlength="256" name="freq" :placeholder="data.gsu.one.freq" required="" />
                <div><strong>Gain</strong></div><input type="number" class="w-input" maxlength="256" name="gain" :placeholder="data.gsu.one.gain" required="" />
                <input type="submit" value="Submit" class="w-button" />
            </form>
        </div>
        <div class="w-form">
            <form @submit="submit" name="/gsd/one">
                <div class="text-block"><strong>Downlink Ground Station (Receive)</strong></div>
                <div><strong>Frequency</strong></div><input type="number" class="w-input" maxlength="256" name="freq" :placeholder="data.gsd.one.freq" required="" />
                <div><strong>Gain</strong></div><input type="number" class="w-input" maxlength="256" name="gain" :placeholder="data.gsd.one.gain" required="" />
                <input type="submit" value="Submit" class="w-button" />
            </form>
        </div>
    </div>
</template>

<style>
    @import '../style/ModemConfig.css';
</style>

<script>

    export default {
      name: 'DemoOne',
      props: {
        data: Object,
        staticdata: Object
      },
      methods: {
        submit(event){
          this.$root.submit(event);
        }
      }
    }
  </script>