<template>
    <figure class="highcharts-figure">
        <highcharts :options="chartOptions"></highcharts>
    </figure>
</template>

<style scoped>
    .highcharts-figure,
    .highcharts-data-table table {
        min-width: 360px;
        max-width: 800px;
        margin: 1em auto;
    }

    .highcharts-data-table table {
        font-family: Verdana, sans-serif;
        border-collapse: collapse;
        border: 1px solid #ebebeb;
        margin: 10px auto;
        text-align: center;
        width: 100%;
        max-width: 500px;
    }

    .highcharts-data-table caption {
        padding: 1em 0;
        font-size: 1.2em;
        color: #555;
    }

    .highcharts-data-table th {
        font-weight: 600;
        padding: 0.5em;
    }

    .highcharts-data-table td,
    .highcharts-data-table th,
    .highcharts-data-table caption {
        padding: 0.5em;
    }

    .highcharts-data-table thead tr,
    .highcharts-data-table tr:nth-child(even) {
        background: #f8f8f8;
    }

    .highcharts-data-table tr:hover {
        background: #f1f7ff;
    }
</style>



<script>
    import {Chart} from 'highcharts-vue'

    const n = 1000;
    const noisefloor = -10
    const minwavelength = 0
    const waverange = 300
    const noiseamplitude = 20


    export default {
        name: 'SpectrometerComponent',
        props: {
            data: Object
        },
        components: {
            highcharts: Chart 
        },
        data() {
            return {
                chartOptions: {
                    credits: {
                        enabled: false
                    },
                    chart: {
                        zoomType: 'xy'
                    },
                    title: {
                        text: 'Spectrometer'
                    },
                    tooltip: {
                        valueDecimals: 2
                    },
                    xAxis: {    //The x axis contains the range of frequencies measured by the spectrometer
                        type: 'linear',
                        title: {
                            text: 'Frequency (MHz)'
                        }
                    },
                    yAxis: {    //The y axis is set to a logarithmic scale, and it displays the decibels measured
                        type: 'linear',
                        title: {
                            text: 'dB'
                        }
                    },
                    series: [{
                        data: this.getData(),
                        lineWidth: 2.0,
                        pointStart: minwavelength,
                        pointInterval: 300/n,
                        name: 'Signal',
                        animation: false
                    }],
                },
                plotOptions: {
                    series: {
                        animation: false
                    }
                }
            }
        },
        created () {
            setInterval(this.updateChart, 100);
        },
        methods: {
            submit(event){
                this.$root.submit(event);
            },
            async updateChart() {
                this.chartOptions.series[0].data = this.getData();
            },
            getData() {
                var setsofdata = [ this.$root.data.speca.gsd.one.freq, this.$root.data.speca.gsd.one.bandwidth, this.$root.data.speca.gsd.one.power]     //The first value is the frequency, the second is the range of the frequency, and the third is the amplitude
                var arr = [], i, x, a, extranoise;
                for (i = 0, x=minwavelength; i < n; i = i + 1, x = minwavelength + (waverange/n)*i) {
                    if((x >= (setsofdata[0] - (setsofdata[1]/2))) && (x <= (setsofdata[0] + setsofdata[1]/2)) ) {
                        a = setsofdata[2]; //In the event that the frequency is the provided value, or falls within the range provided, the amplitude
                        //of the wave is set to the provided amplitude
                    } else{
                        a = 0;  //otherwise the amplitude is set to 0
                    }
                    extranoise = Math.random() * noiseamplitude;
                    arr.push([noisefloor + a + extranoise]); //The noise floor is added to the amplitude of the wave to create the final value
                }
                return arr;
            }
        }
    }
</script>