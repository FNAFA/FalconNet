import { createApp } from 'vue'
import LoadScript from "vue-plugin-load-script";
import App from './App.vue'
import router from './router'
import HighchartsVue from 'highcharts-vue'
import VueCookies from 'vue-cookies'

createApp(App).use(router).use(LoadScript).use(HighchartsVue).use(VueCookies).mount('#app')