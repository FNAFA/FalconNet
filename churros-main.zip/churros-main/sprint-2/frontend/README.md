# ChURROS Frontend

Frontend written in Vue, pulls data from backend using REST API.

Endpoints:
* `/` - team select page
* `/white` - white team dashboard
* `/red` - red team dashboard
* `/blue` - blue team dashboard

# Usage
```
sh run.sh
```

# Setup

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
