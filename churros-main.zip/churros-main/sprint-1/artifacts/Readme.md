# Spring 1 Artifiacts


## Proof of Concepts

### Frontend

- [x] React
- [x] Handlebars
- [x] Vue
- [x] Raw JavaScript
- [ ] Angular


### Backend

- [x] FastAPI
- [x] Raw PHP/SQL
- [ ] Django


## Documents

- [x] Sprint 1 Rubric
- [x] Framework Demo Requirements
- [x] Framework Evaluation
- [ ] Future roadmap