# Project roadmap

## Current decisions

- We will use Vue for the frontend
- We will use FastAPI for the backend

## Future ideas

### Key components of minimum viable product

#### Spectrometer (client-side)
 - (Highcharts)[https://www.highcharts.com/]
 - Noise should be applied client-side - random noise generation necessary

#### Basic user interface
 - (Vue)[https://vuejs.org/]
 - (Bootstrap)[https://getbootstrap.com/]

#### Link budget calculator (server-side)
 - Likely implemented in with a (Python class)[https://docs.python.org/3/tutorial/classes.html] for each link compoenent

#### Login functionality (server-side)
 - FastAPI's (OAuth2)[https://fastapi.tiangolo.com/tutorial/security/oauth2-jwt/] support
 - Use a .env file to initialize the login credentials (see (this)[https://fastapi.tiangolo.com/advanced/settings/])
 - Apply access restrictions to API endpoints based on user role

 #### Logging (server-side)
 - Timestamp each request - get current time in Python
 - Convert list of timestamped requests to a CSV file


 ### Minimum viable product features

 - User can log in with either a white, red, or blue cell credentials
 - Red cell has read access to following components:
    - Spectrometer
    - Modem lock status indicator
 - Red cell has write access to following components:
    - Modem configuration (frequency and power settings)
- Blue cell has access to following components:
    - Spectrometer
- Blue cell has write access to following components:
    - Modem configuration (frequency and power settings)
- White cell has read access to following components:
    - Spectrometer
    - Modem lock status indicator
    - Modem configuration (frequency and power settings)


