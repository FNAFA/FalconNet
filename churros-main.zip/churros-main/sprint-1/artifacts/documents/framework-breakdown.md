# Frontend

### React

#### Pros:

1. Meets all demo requirements
2. Updates frontend code live
3. Simple to build and deploy

#### Cons:

1. Somewhat unique language - relatively complicated

### Handlebars

#### Pros:

1. Does not require any additional components - pure JavaScript
2. Very simple and straightforward for basic tasks/templating

 #### Cons:

1. Only provides templating - does not provide async data loading
2. Does not control form submission behavior
3. Requires significant amounts of hand-written code

### Angular

#### Pros:

1. 
2. 

 #### Cons:

1. Difficult to learn and understand
2. Documentation is not clear

### no framework (Plain old JavaScript)

#### Pros:

1. Does not require any additional components - pure JavaScript
2. Lots of tutorials and resources to learn and understand

 #### Cons:

1. Requires significant amounts of hand-written code
2. Does not simplify any complex processes (REST API use, etc.)

### Vue

#### Pros:

1. Simple to have multiple screens
2. Simple to organize multiple components
3. Tutorials make sense, easy to learn
4. Can accomplish get and pull requests easily for single pieces of data

 #### Cons:

1. Syntax is different from what we are used to

# Backend

### Django

### FastAPI

#### Pros:

1. Extremely effecient language - very little code required to implement REST API
2. Automatically builds full documentation with built-in tests
3. Is relatively portable - runs on python

#### Cons:

1. Does not natively store data in SQL database - requires additional setup
