# Sprint 1 - Demo Requirements

## Requirements

 #### Frontend

  - Must implement an async REST API to load data from server to fill in template
  - Must display a button centered on screen
  - Must query server to determine the current color to set the background color of the screen at least once per second
  - Must update the background color of the screen when a new color is received
  - Must send a POST request to the server when the button is clicked notifying of the new color


#### Backend
 - Must implement a REST API
 - Must maintain a persistent database
 - Must store the current state of the background color
 - Must modify the background color of the screen in the database bassed on POST requests from the frontend



 #### REST API
 - GET /api/color
   - Returns current background color
   - Example return values: "red", "blue", "green"
   - Example response: `{"color":"red"}`

- POST /api/color
  - Request body includes JSON update
  - Example colors: "red", "blue", "green"
  - Example request: `{"color":"green"}`
  - Returns HTTP status code 200 on success