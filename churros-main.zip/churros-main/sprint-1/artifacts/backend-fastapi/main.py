from fastapi import FastAPI, Request
from starlette.responses import FileResponse 
from starlette.requests import Request
from fastapi.middleware.cors import CORSMiddleware

# Initialize the FastAPI app
app = FastAPI()


# CORS configuration
#   This is necessary to allow the frontend to make requests to the backend 
origins = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Set initial state (app.state holds the entire DB for the app as a dict)
app.state.color = "red"

# Define the routes

#  GET /color - returns the current color
@app.get("/api/color")
async def root():
    return {"color": app.state.color}

# POST /color - sets the current color
@app.post("/api/color")
async def change_color(request: Request):
    info = await request.json()
    app.state.color = info["color"]