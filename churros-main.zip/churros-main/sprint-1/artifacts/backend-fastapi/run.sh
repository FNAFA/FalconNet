#!/bin/sh

# Start the backend
uvicorn main:app --reload