import React from 'react'

const { register, handleSubmit } = useForm();
const onSubmit = (data, e) => {
const requestOptions = {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
};
fetch(APIServer, requestOptions)
console.log(data, e);
}
const onError = (errors, e) => {
console.log(errors, e);
}

const Demo = ({ color }) => {
    return (
        <div
          style={{
            backgroundColor: {color},
            height: '100vh',
            width: '100vw',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
        >
          <form onSubmit={handleSubmit(onSubmit, onError)}>
            <input {...register("color")} />
            <button type="submit">Submit</button>
          </form>
        </div>
      );
};

export default Demo