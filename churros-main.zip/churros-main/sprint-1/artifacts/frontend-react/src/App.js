import './App.css';
import React, { useState, useEffect } from 'react'
import { useForm } from "react-hook-form";


const APIServer = "http://localhost:8000/api"

function App() {

  const [APIData, fetchColors] = useState([])

  const getData = () => {
    fetch(APIServer + '/color')
      .then((res) => res.json())
      .then((res) => {
        fetchColors(res)
      })
  }

  useEffect(() => {
    getData()
    const interval = setInterval(() => {
      getData()
    }, 1000);
    return () => clearInterval(interval);
  }, [])

  const { register, handleSubmit } = useForm();
  const onSubmit = (data, e) => {
    const requestOptions = {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    };
    fetch(APIServer + '/color', requestOptions)
    console.log(APIData.color);
    getData();
  }
  const onError = (errors, e) => {
    console.log(errors, e);
  }

  return (
    <div
      style={{
        backgroundColor: APIData.color,
        height: '100vh',
        width: '100vw',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }}
    >
      <form onSubmit={handleSubmit(onSubmit, onError)}>
        <select {...register("color")}>
          <option value="red">red</option>
          <option value="blue">blue</option>
          <option value="green">green</option>
        </select>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
}

export default App;