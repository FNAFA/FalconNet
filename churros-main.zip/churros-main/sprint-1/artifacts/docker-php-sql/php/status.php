<?php
$servername = "db";
$username = "devuser";
$password = "devpass";
$dbname = "test_db";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT color FROM status WHERE id = 1";
$result = mysqli_query($conn, $sql);
$color = 0;

if (mysqli_num_rows($result) > 0) {
  // output data of each row
  while($row = mysqli_fetch_assoc($result)) {
    $color = $row["color"];
  }
}

mysqli_close($conn);

print('{"color":' . $color . '}');
?>