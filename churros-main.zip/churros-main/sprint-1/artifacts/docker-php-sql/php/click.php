<?php
$servername = "db";
$username = "devuser";
$password = "devpass";
$dbname = "test_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


// Set color to POST parameter color
$data = json_decode(file_get_contents('php://input'), true);
$color = $data["color"];

$id = 1;
// Set new color
$stmt = $conn->prepare("UPDATE status SET color = ? WHERE id = ?;");
$stmt->bind_param("ii", $color, $id);


$stmt->execute();
$stmt->close();


$conn->close();
?>