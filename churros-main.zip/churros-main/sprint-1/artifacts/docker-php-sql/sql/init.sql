USE test_db;
CREATE TABLE IF NOT EXISTS status (
    id INT AUTO_INCREMENT PRIMARY KEY,
    color INT
);

INSERT INTO status (id,color) VALUES (0,0);