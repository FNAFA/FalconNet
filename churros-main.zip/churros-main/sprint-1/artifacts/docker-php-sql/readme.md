# Docker - PHP - mySQL Proof of Concept

## Description

This is just a simple web application written in PHP (using a mySQL DB and JS frontend), which is packaged into a Docker container.

The goal of this application is two-fold: to provide a baseline against which the frameworks can be evaluated, and to provide a simple example of how to package a web application into a Docker container.

## Usage
`docker-compose up`