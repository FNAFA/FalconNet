import { HttpClient, HttpParams } from '@angular/common/http';

const apiLink = 'http://localhost:8000/api';
const colorEP = '/color';

export class talkToAPI{
    constructor(private http: HttpClient) {}

    doPost (color:string){
        return this.http.post(apiLink, color);
    }
}