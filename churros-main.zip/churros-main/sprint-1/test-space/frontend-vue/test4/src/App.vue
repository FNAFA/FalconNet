<template>
  <nav>
    <router-link to="/">Home</router-link> |
    <router-link to="/about">About</router-link>
  </nav>
  <router-view :data="data"/>
</template>


<script>  
  const APIServer = "http://localhost:8000/api";
  
  const sources = [
    "/color"
  ]
  
  export default {
    data () {
        return {
            data: [],
            timer: ''
        }
    },
    created () {
        this.fetchEventsList();
        this.timer = setInterval(this.fetchEventsList, 1000);
    },
    name: 'HomeView',
    methods: {
        async fetchEventsList () {
            for (let source of sources) {
              const response = await fetch(APIServer + source, {
                method: 'GET'
              })
              this.data = Object.assign({}, this.data, await response.json());
            }
            //console.log(this.data);
        },
        cancelAutoUpdate () {
            clearInterval(this.timer);
        },
        submit(event) {
          event.preventDefault();
          var path = event.target.name;
          var formData = new FormData(event.target);
          var object = {};
          formData.forEach(function(value, key){
              object[key] = value;
          });
          var json = JSON.stringify(object);
          fetch(APIServer + path, {
            method: 'POST',
            body: json
          })
          this.fetchEventsList();
        }
    },
    beforeUnmount () {
      this.cancelAutoUpdate();
    },
  }
  </script>