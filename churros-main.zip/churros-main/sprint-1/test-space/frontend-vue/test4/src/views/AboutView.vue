<template>
  <div class="about">
    <h1>This is a demo second page</h1>
  </div>
</template>
