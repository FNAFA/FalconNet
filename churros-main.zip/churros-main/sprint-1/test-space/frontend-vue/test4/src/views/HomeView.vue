<template>
  <DemoComponent :data="data"></DemoComponent>
</template>

<script>
import DemoComponent from '@/components/DemoComponent.vue';

//const APIServer = "http://localhost:8000/api";

export default {
  
  props: {
    data: Object
  },
  components: {
    DemoComponent
  },
  methods: {
    submit(event){
      console.log(this.$parent);
      this.$parent.submit(event);
    }
    /*submit(event) {
          event.preventDefault();
          var path = event.target.name;
          var formData = new FormData(event.target);
          var object = {};
          formData.forEach(function(value, key){
              object[key] = value;
          });
          var json = JSON.stringify(object);
          fetch(APIServer + path, {
            method: 'POST',
            body: json
          })
          this.fetchEventsList();
        }*/
  }
}
</script>