<template>
  <div :style="'background-color:' + data.color + '; height: 100vh; width: 100vw; display: flex; align-items: center; justify-content: center;'">
      <form @submit="submit" name="/color">
          <select name="color">
              <option value="red">red</option>
              <option value="green">green</option>
              <option value="blue">blue</option>
              <option value="white">white</option>
          </select>
          <input type="submit"/>
      </form>
  </div>
</template>


<script>
const APIServer = "http://localhost:8000/api";

const sources = [
  "/color"
]

export default {
  data () {
      return {
          data: [],
          timer: ''
      }
  },
  created () {
      this.fetchEventsList();
      this.timer = setInterval(this.fetchEventsList, 1000);
  },
  methods: {
      async fetchEventsList () {
          for (let source of sources) {
            const response = await fetch(APIServer + source, {
              method: 'GET'
            })
            this.data = Object.assign({}, this.data, await response.json());
          }
          //console.log(this.data);
      },
      cancelAutoUpdate () {
          clearInterval(this.timer);
      },
      submit(event) {
        event.preventDefault();
        var path = event.target.name;
        var formData = new FormData(event.target);
        var object = {};
        formData.forEach(function(value, key){
            object[key] = value;
        });
        var json = JSON.stringify(object);
        fetch(APIServer + path, {
          method: 'POST',
          body: json
        })
        this.fetchEventsList();
      }
  },
  beforeUnmount () {
    this.cancelAutoUpdate();
  },
}
</script>