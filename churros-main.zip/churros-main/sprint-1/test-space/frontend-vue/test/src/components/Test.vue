<template>
  <div :style="'background-color:' + data.color + '; height: 100vh; width: 100vw; display: flex; align-items: center; justify-content: center;'">
      <form @submit="submit" name="/color">
          <select name="color">
              <option value="red">red</option>
              <option value="green">green</option>
              <option value="blue">blue</option>
              <option value="white">white</option>
          </select>
          <input type="submit"/>
      </form>
  </div>
</template>

<script>
  export const sources = [
    "/color"
  ]
</script>