<template>
  <div class="color" :style="'background-color:' + data.color">
      <form @submit="submit" name="/color">
          <select name="color">
              <option value="red">red</option>
              <option value="green">green</option>
              <option value="blue">blue</option>
              <option value="white">white</option>
          </select>
          <input type="submit"/>
      </form>
  </div>
</template>

<style>
  .color {
    height: 100vh;
    width: 100vw;
    display: flex;
    align-items: center;
    justify-content: center;
  }
</style>

<script>
export default {
  name: 'DemoOne',
  props: {
    data: Object
  },
  methods: {
    submit(event){
        this.$parent.submit(event);
    }
  }
}
</script>