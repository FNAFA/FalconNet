import { createRouter, createWebHistory } from 'vue-router'
import HomePage from './views/Home.vue'
import TestPage from './views/Test.vue'
import DemoPage from './views/Demo.vue'

export default () => createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/',
      name: 'Home',
      component: HomePage,
    },
    {
        path: '/test',
        name: 'Test',
        component: TestPage,
      },
    {
      path: '/demo',
      name: 'Demo',
      component: () => DemoPage,
    }
  ]
})