<template>
    <h1>This is home</h1>
</template>

<script>
    export default {
        name: 'HomePage'
    }
</script>