<template>
    <h1>This is test</h1>
</template>

<script>
    export default {
        name: 'TestPage'
    }
</script>