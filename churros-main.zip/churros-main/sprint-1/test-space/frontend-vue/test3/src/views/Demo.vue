<template>
  <div>
    <h1>Demo</h1>
    <DemoComponent></DemoComponent> 
  </div>
</template>


<script>
  import DemoComponent from '@/components/Demo.vue';
  export default {
    name: 'DemoPage',
    components: {
      DemoComponent
    }
  }
</script>