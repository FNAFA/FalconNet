<template>
  <div id="app">
		<h1>Hi!</h1>
    <a href="/demo">Demo</a>
    <a href="/test">Test</a>
    
    <main>
      <router-view />
    </main>
	</div>
</template>


<script>



const APIServer = "http://localhost:8000/api";

const sources = [
  "/color"
]

export default {
  data () {
      return {
          data: [],
          timer: ''
      }
  },
  created () {
      this.fetchEventsList();
      this.timer = setInterval(this.fetchEventsList, 1000);
  },
  name: 'App',
  methods: {
      async fetchEventsList () {
          for (let source of sources) {
            const response = await fetch(APIServer + source, {
              method: 'GET'
            })
            this.data = Object.assign({}, this.data, await response.json());
          }
          //console.log(this.data);
      },
      cancelAutoUpdate () {
          clearInterval(this.timer);
      },
      submit(event) {
        event.preventDefault();
        var path = event.target.name;
        var formData = new FormData(event.target);
        var object = {};
        formData.forEach(function(value, key){
            object[key] = value;
        });
        var json = JSON.stringify(object);
        fetch(APIServer + path, {
          method: 'POST',
          body: json
        })
        this.fetchEventsList();
      }
  },
  beforeUnmount () {
    this.cancelAutoUpdate();
  },
}
</script>