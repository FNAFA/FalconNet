import DemoOne from './DemoOne'

export default {
  DemoOne
}