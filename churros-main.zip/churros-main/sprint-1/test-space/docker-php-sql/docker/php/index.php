<html>
  <head>
    <style>
        .centered {
          position: fixed; /* or absolute */
          top: 50%;
          left: 50%;
        }
        .body {
          background-color: #ff0000;
        }
    </style>
  </head>
  <body class="body">
    <form class="centered" id="form">
        <select id="color-option">
            <option value="0">Red</option>
            <option value="1">Green</option>
            <option value="2">Blue</option>
        </select>
        <input type="submit"></a>
    </div>
    <script>
        colors = ['#ff0000', '#00ff00', '#0000ff'];


        var form=document.getElementById('form')

        form.addEventListener('submit', function(e) {
            e.preventDefault()

            var color=document.getElementById('color-option').value

            fetch('/click.php', {
                method: 'POST',
                body: JSON.stringify({
                    color:color,
                }),
                headers: {
                    'Content-type': 'application/json; charset=UTF-8',
                }
            })
            .then(function(response){ 
                return response.json()})
            .then(function(data) {
                console.log(data)
                body=document.getElementById("bd")
                title.innerHTML = data.title
                body.innerHTML = data.body  
            }).catch(error => console.error('Error:', error)); 
        });


        async function asyncUpdate() {
            let response = await fetch('/status.php');
            let data = await response.text();
            console.log(colors[JSON.parse(data)["color"]]);
            document.body.style.backgroundColor = colors[JSON.parse(data)["color"]];
        }

        function update() {
            asyncUpdate();
            setTimeout(update, 1000);
        }
        
        update();
    </script>
  </body>
</html>