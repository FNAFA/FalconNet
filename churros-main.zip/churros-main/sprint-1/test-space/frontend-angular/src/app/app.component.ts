import { Component, ViewChild } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { Injectable } from '@angular/core';

const apiLink = 'http://localhost:8000/api';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  template: `<div class="app" id="app" ng-style="background-color: newColor">`
  // styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor(private http:HttpClient){}

  title = 'frontend-angular';
  
  
  
  onSubmit(data: { color: any; }){
    
    var newColor = data.color;
    console.log(newColor);

    fetch(apiLink, {
      method: 'POST',
      body: newColor
    });
    
    var webPage = document.getElementById("app");
    console.log(webPage);
    if(webPage!=null){
      webPage.style.backgroundColor = String(newColor);
    }
  }
}
