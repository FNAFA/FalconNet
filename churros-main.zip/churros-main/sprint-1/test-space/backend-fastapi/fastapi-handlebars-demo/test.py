from fastapi import FastAPI, Request
from starlette.responses import FileResponse 
from starlette.requests import Request
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.state.color = "red"

@app.get("/api/color")
async def root():
    return {"color": app.state.color}

@app.post("/api/color")
async def change_color(request: Request):
    info = await request.json()
    app.state.color = info["color"]


@app.get("/")
async def root():
    return FileResponse('index.html')