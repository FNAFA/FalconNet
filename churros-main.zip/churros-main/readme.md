# ChURROS

### Space Force Weapons School Cloud Simulation Environment


## Sprint 1

* sprint-1/test-space: Our working environment for building and framework testing proof of concept
* sprint-1/artifacts: Our artifacts for the sprint

## Sprint 2

* sprint-2/frontend: Frontend written in Vue, pulls data from backend using REST API, with endpoints `/`, `/white`, `/red`, `/blue`
* sprint-2/backend: Serves a basic proof of concept backend, with documentation at `/docs` and `/redoc`